class Excecao:
    def __init__(self, frase):
        self.frase = frase

    def imprimir(self):
        return print(self.frase)


# como iniciar objeto nulo??
